package com.example.customermanagement.services;

import com.example.customermanagement.models.Province;

public interface ProvinceService extends Service<Province> {

}
